import { CategoryFilter } from '../types/categories';

export const categories: CategoryFilter[] = [
  { id: 'All', label: 'All Products', icon: '🛍️' },
  { id: 'Electronics', label: 'Electronics', icon: '📱' },
  { id: 'Clothing', label: 'Clothing', icon: '👕' },
  { id: 'Shoes', label: 'Shoes', icon: '👟' },
  { id: 'Groceries', label: 'Groceries', icon: '🥑' },
  { id: 'Accessories', label: 'Accessories', icon: '⌚' },
];