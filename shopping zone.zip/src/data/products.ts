export const products = [
  // Electronics
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 299.99,
    description: "High-quality wireless headphones with noise cancellation",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
    category: "Electronics"
  },
  {
    id: 2,
    name: "Smart 4K TV",
    price: 799.99,
    description: "55-inch 4K Smart TV with HDR",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1",
    category: "Electronics"
  },
  {
    id: 3,
    name: "Smartphone Pro",
    price: 999.99,
    description: "Latest smartphone with advanced camera system",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9",
    category: "Electronics"
  },
  {
    id: 4,
    name: "Wireless Gaming Mouse",
    price: 79.99,
    description: "High-precision gaming mouse with RGB lighting",
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46",
    category: "Electronics"
  },
  {
    id: 5,
    name: "Smart Watch Series X",
    price: 349.99,
    description: "Advanced smartwatch with health monitoring",
    image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12",
    category: "Electronics"
  },
  // Clothing
  {
    id: 6,
    name: "Classic White T-Shirt",
    price: 29.99,
    description: "100% cotton premium white t-shirt",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab",
    category: "Clothing"
  },
  {
    id: 7,
    name: "Denim Jacket",
    price: 89.99,
    description: "Vintage style denim jacket",
    image: "https://images.unsplash.com/photo-1523205771623-e0faa4d2813d",
    category: "Clothing"
  },
  {
    id: 8,
    name: "Summer Floral Dress",
    price: 59.99,
    description: "Light and breezy floral print dress",
    image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1",
    category: "Clothing"
  },
  {
    id: 9,
    name: "Slim Fit Chinos",
    price: 49.99,
    description: "Classic khaki chinos for casual wear",
    image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a",
    category: "Clothing"
  },
  {
    id: 10,
    name: "Wool Sweater",
    price: 79.99,
    description: "Warm and comfortable wool blend sweater",
    image: "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9",
    category: "Clothing"
  },
  // Shoes
  {
    id: 11,
    name: "Running Shoes",
    price: 129.99,
    description: "Professional running shoes with air cushion",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
    category: "Shoes"
  },
  {
    id: 12,
    name: "Casual Sneakers",
    price: 79.99,
    description: "Comfortable everyday sneakers",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772",
    category: "Shoes"
  },
  {
    id: 13,
    name: "Leather Oxford Shoes",
    price: 159.99,
    description: "Classic leather oxford dress shoes",
    image: "https://images.unsplash.com/photo-1449505278894-297fdb3edbc1",
    category: "Shoes"
  },
  {
    id: 14,
    name: "Canvas Slip-ons",
    price: 49.99,
    description: "Casual and comfortable slip-on shoes",
    image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77",
    category: "Shoes"
  },
  {
    id: 15,
    name: "High-top Basketball Shoes",
    price: 139.99,
    description: "Professional basketball shoes with ankle support",
    image: "https://images.unsplash.com/photo-1556048219-bb6978360b84",
    category: "Shoes"
  },
  // Groceries
  {
    id: 16,
    name: "Organic Food Bundle",
    price: 49.99,
    description: "Fresh organic vegetables and fruits",
    image: "https://images.unsplash.com/photo-1610348725531-843dff563e2c",
    category: "Groceries"
  },
  {
    id: 17,
    name: "Healthy Snack Pack",
    price: 24.99,
    description: "Assorted nuts and dried fruits",
    image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32",
    category: "Groceries"
  },
  {
    id: 18,
    name: "Artisan Coffee Beans",
    price: 19.99,
    description: "Premium roasted coffee beans",
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e",
    category: "Groceries"
  },
  {
    id: 19,
    name: "Organic Honey",
    price: 15.99,
    description: "Pure raw organic honey",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38",
    category: "Groceries"
  },
  {
    id: 20,
    name: "Gourmet Tea Collection",
    price: 34.99,
    description: "Assorted premium tea varieties",
    image: "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9",
    category: "Groceries"
  },
  // Accessories
  {
    id: 21,
    name: "Minimalist Watch",
    price: 199.99,
    description: "Elegant minimalist watch with leather strap",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    category: "Accessories"
  },
  {
    id: 22,
    name: "Leather Backpack",
    price: 129.99,
    description: "Durable leather backpack with multiple compartments",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62",
    category: "Accessories"
  },
  {
    id: 23,
    name: "Designer Sunglasses",
    price: 159.99,
    description: "UV protection designer sunglasses",
    image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083",
    category: "Accessories"
  },
  {
    id: 24,
    name: "Silver Necklace",
    price: 89.99,
    description: "Sterling silver pendant necklace",
    image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338",
    category: "Accessories"
  },
  {
    id: 25,
    name: "Leather Wallet",
    price: 49.99,
    description: "Genuine leather bifold wallet",
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93",
    category: "Accessories"
  }
];