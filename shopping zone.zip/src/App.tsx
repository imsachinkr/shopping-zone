import React, { useState } from 'react';
import { ShoppingCart as CartIcon } from 'lucide-react';
import { CartProvider } from './context/CartContext';
import { ProductGrid } from './components/ProductGrid';
import { CategoryFilter } from './components/CategoryFilter';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { products } from './data/products';
import { Category } from './types/categories';

function App() {
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');

  return (
    <CartProvider>
      <div className="min-h-screen bg-gray-100">
        <header className="bg-white shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">E-Commerce Store</h1>
            <button
              onClick={() => setShowCart(!showCart)}
              className="p-2 hover:bg-gray-100 rounded-full relative"
            >
              <CartIcon size={24} />
            </button>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-8">
          {showCheckout ? (
            <Checkout />
          ) : showCart ? (
            <div>
              <Cart />
              <div className="mt-6 text-center">
                <button
                  onClick={() => setShowCheckout(true)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Proceed to Checkout
                </button>
              </div>
            </div>
          ) : (
            <>
              <CategoryFilter
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
              />
              <ProductGrid 
                products={products}
                category={selectedCategory}
              />
            </>
          )}
        </main>
      </div>
    </CartProvider>
  );
}

export default App;