export type Category = 'All' | 'Electronics' | 'Clothing' | 'Shoes' | 'Groceries' | 'Accessories';

export interface CategoryFilter {
  id: Category;
  label: string;
  icon: string;
}