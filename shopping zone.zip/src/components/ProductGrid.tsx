import React from 'react';
import { Product } from '../types/index';
import { ProductCard } from './ProductCard';
import { Category } from '../types/categories';

interface ProductGridProps {
  products: Product[];
  category: Category;
}

export const ProductGrid: React.FC<ProductGridProps> = ({ products, category }) => {
  const filteredProducts = category === 'All' 
    ? products 
    : products.filter(product => product.category === category);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredProducts.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};